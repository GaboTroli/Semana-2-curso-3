package com.gabriel.tarea_semana2_curso3;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Button;
import android.widget.Toast;

public class activity2 extends AppCompatActivity {

    public  TextView nombreTv;
    public  TextView telefonoTv;
    public  TextView emailTv;
    public  TextView contactoTv;
    public  TextView fechaTv;
    public  Button  editar;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_activity2);

        editar =  findViewById(R.id.editarbtn);
        nombreTv = findViewById(R.id.nombretv);
        telefonoTv = findViewById(R.id.telefonotv);
        emailTv = findViewById(R.id.emailtv);
        fechaTv = findViewById(R.id.fechatv);
        contactoTv = findViewById(R.id.contactotv);



        Bundle parametros = this.getIntent().getExtras();
        if(parametros !=null){

            String nombre= getResources().getString(R.string.nombre) + " " + parametros.getString("nombreIntent");
            String telefono= getResources().getString(R.string.telefono) + " " + parametros.getString("telefonoIntent");
            String email= getResources().getString(R.string.email) + " " + parametros.getString("emailIntent");
            String contacto= getResources().getString(R.string.descripcion) + " " + parametros.getString("contactoIntent");
            String año= parametros.getString("añoIntent");
            String mes= parametros.getString("mesIntent");
            String dia= parametros.getString("diaIntent");
            String fecha = getResources().getString(R.string.fecha) + " " + dia + "/" + mes + "/" + año;

            nombreTv.setText(nombre);
            telefonoTv.setText(telefono);
            emailTv.setText(email);
            contactoTv.setText(contacto);
            fechaTv.setText(fecha);


            //Toast.makeText(this, fecha, Toast.LENGTH_SHORT).show();
        }


    }


    public void regresar(View v)
    {
        Bundle parametros = this.getIntent().getExtras();
        Intent intent = new Intent(activity2.this, MainActivity.class);
        intent.putExtra("nombreIntent",parametros.getString("nombreIntent"));
        intent.putExtra("telefonoIntent",parametros.getString("telefonoIntent"));
        intent.putExtra("emailIntent",parametros.getString("emailIntent"));
        intent.putExtra("contactoIntent",parametros.getString("contactoIntent"));

        startActivity(intent);
        finish();
    }
}
