package com.gabriel.tarea_semana2_curso3;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;


public class MainActivity extends AppCompatActivity {

    public EditText nombre ;
    public EditText telefono;
    public EditText email;
    public EditText detalleContacto;
    public DatePicker fecha;
    public int dia,mes,año;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);



        nombre= findViewById(R.id.nombreText);
        telefono= findViewById(R.id.telefonoText);
        email= findViewById(R.id.emailText);
        detalleContacto= findViewById(R.id.descripcion_contactoText);
        fecha=findViewById(R.id.fechaPicker);
        dia=fecha.getDayOfMonth();
        mes=fecha.getMonth();
        año=fecha.getYear();

        Bundle parametros = this.getIntent().getExtras();
        if(parametros !=null){
            String nombret= parametros.getString("nombreIntent");
            String telefonot= parametros.getString("telefonoIntent");
            String emailt= parametros.getString("emailIntent");
            String contactot=parametros.getString("contactoIntent");

            nombre.setText(nombret);
            telefono.setText(telefonot);
            email.setText(emailt);
            detalleContacto.setText(contactot);


        }


    }

    public void nuevaActividad(View v)
    {


        String nombreExtra= nombre.getText().toString();
        String telefonoExtra= telefono.getText().toString();
        String emailExtra= email.getText().toString();
        String detalleContactoExtra= detalleContacto.getText().toString();
        String añoS = Integer.toString(año);
        String mesS = Integer.toString(mes);
        String diaS = Integer.toString(dia);


        Intent intent =  new Intent(MainActivity.this,activity2.class);
        intent.putExtra("nombreIntent",nombreExtra);
        intent.putExtra("telefonoIntent",telefonoExtra);
        intent.putExtra("emailIntent",emailExtra);
        intent.putExtra("contactoIntent",detalleContactoExtra);
        intent.putExtra("añoIntent",añoS);
        intent.putExtra("mesIntent", mesS);
        intent.putExtra("diaIntent",diaS);

        startActivity(intent);

    }
}
